import pygame
from constants import *
from asset_manager import assets
from procedural_assets import ProceduralAssets

class IntroSequence:
    def __init__(self, screen):
        self.screen = screen
        self.timer = 0
        self.scene = 1
        self.finished = False
        
        # Fonts
        self.font = pygame.font.SysFont("Georgia", 30, italic=True)
        self.title_font = pygame.font.SysFont("Arial", 50, bold=True)
        
        # Entities for intro
        self.parrot_pos = [100, GROUND_HEIGHT - 60]
        self.parrot_frame = 0
        self.fox_pos = [-100, GROUND_HEIGHT - 60]
        self.camera_x = 0
        self.alpha_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.alpha_surface.set_alpha(0)
        
        # Audio
        # Assuming we might want to play music here if we had it
        
    def update(self):
        self.timer += 1
        
        # Scene 1: Jungle Opening (0 - 5s)
        if self.timer < 300:
            self.scene = 1
            self.camera_x += 1 # Pan
            
        # Scene 2: Character Story (5 - 10s)
        elif self.timer < 600:
            self.scene = 2
            # Parrot appears static
            
        # Scene 3: Determination (10 - 15s)
        elif self.timer < 900:
            self.scene = 3
            # Parrot runs
            self.parrot_pos[0] += 2
            self.parrot_frame += 0.2
            
        # Scene 4: Motivation (15 - 20s)
        elif self.timer < 1200:
            self.scene = 4
            self.parrot_pos[0] += 2
            self.parrot_frame += 0.2
            # Show coins? drawn in draw()
            
        # Scene 5: Threat (20 - 25s)
        elif self.timer < 1500:
            self.scene = 5
            self.parrot_pos[0] += 2
            self.parrot_frame += 0.2
            # Fox chases
            self.fox_pos[0] = self.parrot_pos[0] - 200
            if self.fox_pos[0] < 50: self.fox_pos[0] = 50
            
        # Scene 6: Hero Reveal (25 - 30s)
        elif self.timer < 1800:
            self.scene = 6
        
        # Scene 7: Controls (30 - 35s)
        elif self.timer < 2100:
            self.scene = 7
        
        else:
            self.finished = True

    def draw(self):
        self.screen.fill(SKY_COLOR)
        
        # Draw background with camera offset
        # Simplistic procedural background for intro
        ground_color = (30, 100, 30)
        pygame.draw.rect(self.screen, ground_color, (0, GROUND_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_HEIGHT))
        
        # Hills
        for i in range(5):
            x = i * 200 - (self.camera_x * 0.2 % 200)
            pygame.draw.circle(self.screen, (20, 80, 40), (int(x), GROUND_HEIGHT), 150)

        # Text Helper
        def draw_text_centered(text, y_offset=0, color=(255, 255, 255), size_mult=1):
            s = self.font.render(text, True, color)
            rect = s.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + y_offset))
            # Background for text efficiency
            bg_rect = rect.inflate(20, 10)
            overlay = pygame.Surface(bg_rect.size)
            overlay.set_alpha(100)
            overlay.fill((0,0,0))
            self.screen.blit(overlay, bg_rect.topleft)
            self.screen.blit(s, rect)

        # Logic per scene
        if self.scene == 1:
            draw_text_centered("His name is Bash.")
            
        elif self.scene == 2:
            # Draw static parrot
            ProceduralAssets.draw_parrot(self.screen, SCREEN_WIDTH//2 - 30, self.parrot_pos[1], 60, 60, 0, 'idle')
            draw_text_centered("An orphan... alone in the jungle.", -100)
            draw_text_centered("Born with wings that don't work.", 0)
            
        elif self.scene == 3:
            # Draw running parrot (simulated relative pos)
            cx = SCREEN_WIDTH//2 - 30
            ProceduralAssets.draw_parrot(self.screen, cx, self.parrot_pos[1], 60, 60, self.parrot_frame, 'run')
            draw_text_centered("But he never stopped running.", 100)
            
        elif self.scene == 4:
            cx = SCREEN_WIDTH//2 - 30
            # Coins
            for i in range(3):
                coin_x = cx + 100 + i*50 - (self.timer % 50)
                pygame.draw.circle(self.screen, (255, 215, 0), (int(coin_x), int(self.parrot_pos[1] - 20)), 10)
            
            ProceduralAssets.draw_parrot(self.screen, cx, self.parrot_pos[1], 60, 60, self.parrot_frame, 'run')
            draw_text_centered("He runs to collect money...", -120)
            draw_text_centered("$10,000 for a surgery to fly again.", -70)
            
        elif self.scene == 5:
            # Threat
            # Darken
            shade = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            shade.set_alpha(100)
            shade.fill((0,0,50)) # Dark blue tint
            
            cx = SCREEN_WIDTH//2 + 50
            # Fox
            fx = cx - 200
            
            # Draw Parrot
            ProceduralAssets.draw_parrot(self.screen, cx, self.parrot_pos[1], 60, 60, self.parrot_frame, 'run')
            
            # Draw Fox
            pygame.draw.rect(self.screen, (255, 100, 0), (fx, self.parrot_pos[1], 80, 60)) # Placeholder Fox
            # Eyes
            pygame.draw.circle(self.screen, (255,255,255), (int(fx + 60), int(self.parrot_pos[1] + 20)), 8)
            pygame.draw.circle(self.screen, (0,0,0), (int(fx + 62), int(self.parrot_pos[1] + 20)), 3)
            
            self.screen.blit(shade, (0,0))
            draw_text_centered("But danger follows him...", -100)
            draw_text_centered("A fox wants to steal the money!", 50, (255, 100, 100))
            
        elif self.scene == 6:
            # Hero Reveal - Close up
            scale = 3
            cx = SCREEN_WIDTH//2 - (60*scale)//2
            cy = SCREEN_HEIGHT//2 - (60*scale)//2
            
            ProceduralAssets.draw_parrot(self.screen, cx, cy, 60*scale, 60*scale, 0, 'idle')
            # Gun
            pygame.draw.rect(self.screen, (0, 255, 255), (cx + 40*scale, cy + 20*scale, 30*scale, 10*scale))
            
            draw_text_centered("BASH", 150, (255, 255, 0))
            
        elif self.scene == 7:
            # Controls
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(200)
            overlay.fill((0,0,0))
            self.screen.blit(overlay, (0,0))
            
            draw_text_centered("CONTROLS", -150, (0, 255, 255))
            
            # Icons (Simple drawings)
            # SPACE
            rect_space = pygame.Rect(SCREEN_WIDTH//2 - 100, SCREEN_HEIGHT//2 - 80, 200, 40)
            pygame.draw.rect(self.screen, (255,255,255), rect_space, 2)
            draw_text_centered("SPACE - JUMP", -60)
            
            # DOWN
            draw_text_centered("DOWN - CRAWL", 20)
            
            # F
            draw_text_centered("F - SHOOT", 100)
            
            draw_text_centered("PRESS SPACE TO START", 200, (255, 50, 50))
