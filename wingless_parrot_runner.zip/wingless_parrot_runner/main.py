import pygame
import random
import sys
import traceback
from constants import *
from asset_manager import assets
from player import Parrot
from game_objects import Obstacle, Fox, Bullet, JungleBackground
from intro_system import IntroSequence

print("Imports successful")

# Setup debug logging
with open("game_log.txt", "w") as f:
    f.write("Game started\n")

pygame.init()
pygame.mixer.init()

print("Pygame initialized")

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption(TITLE)
clock = pygame.time.Clock()
font = pygame.font.SysFont("Comic Sans MS", 24)
large_font = pygame.font.SysFont("Comic Sans MS", 48)

print("Screen set")

# Audio
go_back_sound = None
try:
    sound_path = f"{ASSET_DIR}/go_back.mp3"
    go_back_sound = pygame.mixer.Sound(sound_path)
    print("Audio loaded")
except Exception as e:
    print(f"Audio not found: {e}")

def draw_text(surface, text, font_obj, color, center_x, center_y):
    img = font_obj.render(text, True, color)
    rect = img.get_rect(center=(center_x, center_y))
    surface.blit(img, rect)

def main():
    try:
        print("Entering main()")
        state = "INTRO" # Start with Intro
        
        print("Creating player...")
        player = Parrot()
        print("Player created")
        
        obstacles = pygame.sprite.Group()
        enemies = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        all_sprites = pygame.sprite.Group()
        all_sprites.add(player)

        print("Creating background...")
        background = JungleBackground()
        print("Background created")
        
        intro = IntroSequence(screen)

        scroll_speed = SCROLL_SPEED
        score = 0
        distance = 0
        spawn_timer = 0
        fox_timer = 0
        
        running = True
        print("Starting loop")
        with open("game_log.txt", "a") as log:
            log.write("Loop starting\n")
            
        frames = 0
        while running:
            dt = clock.tick(FPS)
            frames += 1
            if frames % 60 == 0:
               # print(f"Frame {frames}, State: {state}")
               pass
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                if event.type == pygame.KEYDOWN:
                    if state == "INTRO":
                        # Skip intro
                        if event.key == pygame.K_SPACE:
                            state = "PLAYING"
                            # Reset game
                            player = Parrot()
                            all_sprites.empty()
                            all_sprites.add(player)
                    
                    elif state == "START":
                        if event.key == pygame.K_SPACE:
                            state = "PLAYING"
                            # Reset
                            player = Parrot()
                            obstacles.empty()
                            enemies.empty()
                            bullets.empty()
                            all_sprites.empty()
                            all_sprites.add(player)
                            score = 0
                            distance = 0
                            scroll_speed = SCROLL_SPEED
                            spawn_timer = 0
                            fox_timer = 0

                    elif state == "PLAYING":
                        if event.key == pygame.K_SPACE:
                            player.jump()
                        if event.key == pygame.K_DOWN:
                            player.crawl()
                        if event.key == pygame.K_f:
                            bullet = player.shoot()
                            if bullet:
                                bullets.add(bullet)
                                all_sprites.add(bullet)

                    elif state == "GAMEOVER":
                        if event.key == pygame.K_r:
                            state = "PLAYING"
                            player = Parrot()
                            obstacles.empty()
                            enemies.empty()
                            bullets.empty()
                            all_sprites.empty()
                            all_sprites.add(player)
                            score = 0
                            distance = 0
                            scroll_speed = SCROLL_SPEED
                            spawn_timer = 0
                            fox_timer = 0

                if event.type == pygame.KEYUP:
                    if state == "PLAYING":
                        if event.key == pygame.K_DOWN:
                            player.uncrawl()

            if state == "INTRO":
                intro.update()
                intro.draw()
                pygame.display.flip()
                if intro.finished:
                    state = "START"

            elif state == "PLAYING":
                scroll_speed += SPEED_INCREASE_RATE
                if scroll_speed > MAX_SPEED: scroll_speed = MAX_SPEED
                
                distance += scroll_speed / 10
                score = int(distance)

                spawn_timer += 1
                if spawn_timer > max(60, 120 - int(score / 50)):
                    spawn_timer = 0
                    if random.random() < 0.7:
                        obs = Obstacle(scroll_speed)
                        obstacles.add(obs)
                        all_sprites.add(obs)
                
                fox_timer += 1
                if fox_timer > 400: # Slightly longer gap
                    # Warning sound
                    if go_back_sound:
                        go_back_sound.play()
                    
                    # Spawn fox after short delay?
                    fox = Fox(scroll_speed)
                    enemies.add(fox)
                    all_sprites.add(fox)
                    fox_timer = 0

                player.update()
                obstacles.update(scroll_speed)
                enemies.update(scroll_speed)
                bullets.update(scroll_speed)
                background.update(scroll_speed)

                # Collisions
                hits = pygame.sprite.groupcollide(enemies, bullets, False, True) # Keep enemy, kill bullet
                for enemy, bullet_list in hits.items():
                    if isinstance(enemy, Fox):
                        enemy.hit()
                        score += 100
                    else:
                        enemy.kill() 
                
                # Remove killed/offscreen enemies
                for e in list(enemies):
                    if not e.alive():
                         enemies.remove(e)

                if pygame.sprite.spritecollide(player, obstacles, False):
                    state = "GAMEOVER"
                
                enemy_hits = pygame.sprite.spritecollide(player, enemies, False)
                for e in enemy_hits:
                    if isinstance(e, Fox):
                        if not e.is_hit:
                            state = "GAMEOVER"
                    else:
                        state = "GAMEOVER"
            
                # Draw Playing
                background.draw(screen)
                all_sprites.draw(screen)
                draw_text(screen, f"Score: {score}", font, BLACK, 70, 30)
                pygame.display.flip()

            elif state == "START":
                background.draw(screen) # Show BG on start too
                
                overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
                overlay.set_alpha(100)
                overlay.fill((200, 240, 255))
                screen.blit(overlay, (0,0))
                
                draw_text(screen, TITLE, large_font, BLACK, SCREEN_WIDTH/2, SCREEN_HEIGHT/3)
                # draw instructions
                draw_text(screen, "SPACE: Jump | DOWN: Duck | F: Shoot", font, BLACK, SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
                draw_text(screen, "Press SPACE to Start", font, RED, SCREEN_WIDTH/2, SCREEN_HEIGHT/2 + 60)
                pygame.display.flip()

            elif state == "GAMEOVER":
                background.draw(screen)
                all_sprites.draw(screen)
                overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
                overlay.set_alpha(150)
                overlay.fill((0,0,0))
                screen.blit(overlay, (0,0))
                draw_text(screen, "GAME OVER", large_font, RED, SCREEN_WIDTH/2, SCREEN_HEIGHT/3)
                draw_text(screen, f"Score: {score}", font, WHITE, SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
                draw_text(screen, "Press R to Restart", font, WHITE, SCREEN_WIDTH/2, SCREEN_HEIGHT/2 + 60)
                pygame.display.flip()

        pygame.quit()
        sys.exit()
    except Exception as e:
        print("CRITICAL ERROR IN MAIN:")
        traceback.print_exc()
        with open("game_log.txt", "a") as log:
            log.write(f"ERROR: {e}\n")
            traceback.print_exc(file=log)

if __name__ == "__main__":
    main()
