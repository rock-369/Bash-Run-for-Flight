import pygame
import math
from constants import *

class ProceduralAssets:
    @staticmethod
    def draw_parrot(surface, x, y, width, height, frame_count, state='run'):
        # Colors
        RED_BODY = (220, 20, 60)
        YELLOW_BEAK = (255, 215, 0)
        WHITE_FACE = (255, 255, 255)
        BLACK_EYE = (0, 0, 0)
        LEG_COLOR = (50, 50, 50)
        
        # Bobbing
        bob = math.sin(frame_count * 0.5) * 3
        
        # Center coordinates
        cx = x + width // 2
        cy = y + height // 2 + bob
        
        # Legs (animate based on state)
        if state == 'run':
            leg_angle = math.sin(frame_count * 0.5) * 0.5
            # Left leg
            lx1 = cx - 5
            ly1 = cy + 15
            lx2 = lx1 + math.sin(leg_angle) * 15
            ly2 = ly1 + math.cos(leg_angle) * 15
            pygame.draw.line(surface, LEG_COLOR, (lx1, ly1), (lx2, ly2), 4)
            # Right leg
            rx1 = cx + 5
            ry1 = cy + 15
            rx2 = rx1 - math.sin(leg_angle) * 15
            ry2 = ry1 + math.cos(leg_angle) * 15
            pygame.draw.line(surface, LEG_COLOR, (rx1, ry1), (rx2, ry2), 4)
        
        # Body (Tear drop shape roughly)
        # Main body
        pygame.draw.ellipse(surface, RED_BODY, (x, cy - height//2, width, height))
        
        # Head (Offset top right)
        head_radius = width // 3
        hx = cx + 5
        hy = cy - height//3
        pygame.draw.circle(surface, RED_BODY, (int(hx), int(hy)), int(head_radius))
        
        # Face (White patch)
        pygame.draw.circle(surface, WHITE_FACE, (int(hx + 5), int(hy - 2)), int(head_radius * 0.7))
        
        # Eye
        pygame.draw.circle(surface, BLACK_EYE, (int(hx + 8), int(hy - 5)), 4)
        
        # Beak
        beak_pts = [
            (hx + 10, hy),
            (hx + 25, hy + 5),
            (hx + 10, hy + 15)
        ]
        pygame.draw.polygon(surface, YELLOW_BEAK, beak_pts)
        
        # Wing (Folded)
        # Even though "wingless", maybe small stubs or just arms? User said "humanoid runner".
        # Let's draw arms swinging
        if state == 'run':
            arm_angle = math.cos(frame_count * 0.5) * 0.5
            ax = cx
            ay = cy
            end_ax = ax + math.sin(arm_angle) * 15
            end_ay = ay + math.cos(arm_angle) * 15
            pygame.draw.line(surface, RED_BODY, (ax, ay), (end_ax, end_ay), 6)

    @staticmethod
    def create_jungle_element(type_name, width, height):
        s = pygame.Surface((width, height), pygame.SRCALPHA)
        if type_name == 'tree':
            # Trunk
            pygame.draw.rect(s, (101, 67, 33), (width//2 - 10, 0, 20, height))
            # Leaves
            pygame.draw.circle(s, (34, 139, 34), (width//2, 20), 40)
            pygame.draw.circle(s, (34, 139, 34), (width//2 - 20, 50), 30)
            pygame.draw.circle(s, (34, 139, 34), (width//2 + 20, 50), 30)
        elif type_name == 'bush':
             pygame.draw.rect(s, (0,0,0,0), (0,0,width,height))
             for i in range(5):
                 bx = (i * width // 5)
                 by = height - 10 - (i%2)*10
                 pygame.draw.circle(s, (50, 205, 50), (bx, by), 15)
        return s
