import pygame
from constants import *
from game_objects import Bullet
from asset_manager import assets
from procedural_assets import ProceduralAssets

class Parrot(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        
        self.anims = assets.get_parrot_animations()
        self.state = 'run'
        self.current_sprites = self.anims['run'] # Might be placeholders
        self.frame_index = 0
        self.animation_speed = 0.25
        
        # Check if assets is actually giving us placeholders or real images
        # We assume if it's the "placeholder" style from AssetManager, we might want to use our ProceduralAssets instead
        # because ProceduralAssets is better (animated).
        # But AssetManager placeholders are static surfaces? The code says they are surfaces.
        # Let's verify: AssetManager creates surfaces with ellipses. ProceduralAssets draws lines and bobs.
        # Ideally we prefer ProceduralAssets if we don't have a real sprite sheet.
        
        # We can create a "procedural" mode.
        self.use_procedural = False
        # Heuristic: Check if the first sprite is 60x60 and mostly empty or check a flag.
        # For this demo, let's FORCE procedural if the user didn't provide a sprite sheet file
        # which we know they didn't (or quota failed).
        # Actually asset_manager returns placeholders if file missing.
        # So let's use ProceduralAssets to draw ONTO the image surface every frame.
        
        self.image = pygame.Surface((PLAYER_WIDTH, PLAYER_HEIGHT), pygame.SRCALPHA)
        self.rect = self.image.get_rect()
        self.rect.x = PLAYER_X_POS
        self.rect.bottom = GROUND_HEIGHT

        self.vel_y = 0
        self.is_jumping = False
        self.is_crawling = False
        self.is_shooting = False
        self.shoot_cooldown = 0
        self.shoot_anim_timer = 0
        
        # Simply, we will redraw the image every update call using ProceduralAssets 
        # because that gives us the best "animated" look without a sprite sheet.
        self.global_frame_count = 0

    def update(self):
        self.global_frame_count += 1
        
        # Gravity
        self.vel_y += GRAVITY
        self.rect.y += self.vel_y

        # Ground Collision
        if self.rect.bottom >= GROUND_HEIGHT:
            self.rect.bottom = GROUND_HEIGHT
            self.vel_y = 0
            self.is_jumping = False
        
        # Cooldown
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        
        # State
        if self.is_shooting and self.shoot_anim_timer > 0:
            self.state = 'shoot'
            self.shoot_anim_timer -= 1
            if self.shoot_anim_timer <= 0:
                self.is_shooting = False
        elif self.is_jumping:
            self.state = 'jump'
        elif self.is_crawling:
            self.state = 'crawl'
        else:
            self.state = 'run'
            
        # Draw Procedurally
        self.image.fill((0,0,0,0)) # Clear
        
        # Adjust dimensions for crawl
        w, h = PLAYER_WIDTH, PLAYER_HEIGHT
        if self.state == 'crawl':
            h = PLAYER_CRAWL_HEIGHT
            w = PLAYER_WIDTH + 10
        
        ProceduralAssets.draw_parrot(self.image, 0, 0, w, h, self.global_frame_count, self.state)
        
        # Rect adjustment
        current_bottom = self.rect.bottom
        current_x = self.rect.x
        self.rect = self.image.get_rect()
        self.rect.bottom = current_bottom
        self.rect.x = current_x

    def jump(self):
        if not self.is_jumping and not self.is_crawling:
            self.vel_y = JUMP_FORCE
            self.is_jumping = True

    def crawl(self):
        if not self.is_crawling and not self.is_jumping:
            self.is_crawling = True
            self.rect.height = PLAYER_CRAWL_HEIGHT
            self.rect.bottom = GROUND_HEIGHT

    def uncrawl(self):
        if self.is_crawling:
            self.is_crawling = False
            self.rect.height = PLAYER_HEIGHT
            self.rect.bottom = GROUND_HEIGHT

    def shoot(self):
        if self.shoot_cooldown == 0:
            self.shoot_cooldown = 20
            self.is_shooting = True
            self.shoot_anim_timer = 15 
            
            bx = self.rect.right
            by = self.rect.centery
            if self.is_crawling:
                by = self.rect.centery + 10
            
            return Bullet(bx, by)
        return None
