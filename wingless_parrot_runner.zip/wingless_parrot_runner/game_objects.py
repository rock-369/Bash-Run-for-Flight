import pygame
import random
from constants import *
from asset_manager import assets
from procedural_assets import ProceduralAssets

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((BULLET_WIDTH, BULLET_HEIGHT))
        self.image.fill(BULLET_COLOR)
        pygame.draw.rect(self.image, (255, 255, 255), (2, 2, BULLET_WIDTH-4, BULLET_HEIGHT-4))
        
        self.rect = self.image.get_rect()
        self.rect.midleft = (x, y)
        self.speed = BULLET_SPEED

    def update(self, scroll_speed=0):
        self.rect.x += self.speed
        if self.rect.left > SCREEN_WIDTH:
            self.kill()

class Obstacle(pygame.sprite.Sprite):
    def __init__(self, start_scroll_speed=SCROLL_SPEED):
        super().__init__()
        self.type = random.choice(['ground', 'ground', 'ground', 'air']) 
        
        width = OBSTACLE_WIDTH
        height = OBSTACLE_HEIGHT
        
        if self.type == 'ground':
            width = random.randint(40, 60)
            height = random.randint(40, 70)
            self.image = pygame.Surface((width, height))
            self.image.fill((101, 67, 33)) # Brown rock/log
            pygame.draw.circle(self.image, (80, 50, 20), (10, 10), 10)
            
            self.rect = self.image.get_rect()
            self.rect.x = SCREEN_WIDTH + random.randint(0, 50)
            self.rect.bottom = GROUND_HEIGHT
        else:
            width = random.randint(50, 70)
            height = random.randint(30, 50)
            self.image = pygame.Surface((width, height))
            self.image.fill((30, 150, 30))
            
            self.rect = self.image.get_rect()
            self.rect.x = SCREEN_WIDTH + random.randint(0, 50)
            self.rect.bottom = GROUND_HEIGHT - PLAYER_CRAWL_HEIGHT - 20
        
        self.base_speed = start_scroll_speed

    def update(self, current_scroll_speed=None):
        speed = current_scroll_speed if current_scroll_speed is not None else self.base_speed
        self.rect.x -= speed
        if self.rect.right < 0:
            self.kill()

class Fox(pygame.sprite.Sprite):
    def __init__(self, start_scroll_speed=SCROLL_SPEED):
        super().__init__()
        self.anims = assets.get_fox_animations()
        self.state = 'run'
        self.sprites = self.anims.get(self.state, [])
        
        self.current_frame = 0
        if self.sprites:
             self.image = self.sprites[0]
        else:
             self.image = pygame.Surface((FOX_WIDTH, FOX_HEIGHT), pygame.SRCALPHA)
             self.draw_procedural()

        self.rect = self.image.get_rect()
        self.rect.x = SCREEN_WIDTH + random.randint(50, 100)
        self.rect.bottom = GROUND_HEIGHT
        
        self.animation_speed = 0.2
        self.base_speed = start_scroll_speed
        self.is_hit = False

    def draw_procedural(self):
        # Fallback procedural fox
        self.image.fill((0,0,0,0))
        color = (255, 100, 0)
        pygame.draw.rect(self.image, color, (10, 20, 60, 30)) # Body
        pygame.draw.circle(self.image, color, (15, 25), 20) # Head
        pygame.draw.polygon(self.image, (255, 255, 255), [(15, 25), (0, 35), (10, 45)]) # Snout
        pygame.draw.rect(self.image, (0,0,0), (60, 25, 20, 10)) # Tail
        
    def hit(self):
        if not self.is_hit:
            self.is_hit = True
            self.state = 'hit'

    def update(self, current_scroll_speed=None):
        base = current_scroll_speed if current_scroll_speed is not None else self.base_speed
        
        if not self.is_hit:
            total_speed = base + 4
            self.rect.x -= total_speed
        else:
            total_speed = base - 2
            self.rect.x -= base
            self.rect.x += 5
            self.rect.y -= 2
            
        # Animation
        if self.sprites:
            self.current_frame += self.animation_speed
            if self.current_frame >= len(self.sprites):
                self.current_frame = 0
            frame_idx = int(self.current_frame)
            if frame_idx < len(self.sprites):
                self.image = pygame.transform.scale(self.sprites[frame_idx], (FOX_WIDTH, FOX_HEIGHT))
        else:
             # Update procedural anim if needed (e.g. wiggle)
             pass

        if self.rect.right < 0 or self.rect.x > SCREEN_WIDTH + 200:
            self.kill()

class JungleBackground:
    def __init__(self):
        # We ignore assets here and build procedural layers for better "Jungle" look
        # as requested by user.
        self.bg_strips = []
        
        # Layer 1: Sky/Hills
        l1 = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        l1.fill(SKY_COLOR)
        # Draw hills
        for i in range(0, SCREEN_WIDTH + 100, 150):
            color = (60 + random.randint(-10,10), 100 + random.randint(-10,10), 60)
            pygame.draw.circle(l1, color, (i, SCREEN_HEIGHT - 50), 200)
        self.bg_strips.append({'img': l1, 'x': 0, 'speed': 0.1})
        
        # Layer 2: Midground (Trees)
        l2 = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        for i in range(0, SCREEN_WIDTH, 200):
            width = random.randint(80, 120)
            height = random.randint(250, 350)
            tree = ProceduralAssets.create_jungle_element('tree', width, height)
            l2.blit(tree, (i, SCREEN_HEIGHT - height))
        self.bg_strips.append({'img': l2, 'x': 0, 'speed': 0.5})
        
        # Layer 3: Foreground (Bushes/Ground)
        l3 = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        # Ground
        pygame.draw.rect(l3, GROUND_COLOR, (0, GROUND_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_HEIGHT))
        # Bushes
        for i in range(50, SCREEN_WIDTH, 150):
            bush = ProceduralAssets.create_jungle_element('bush', 80, 50)
            l3.blit(bush, (i, GROUND_HEIGHT - 40))
        self.bg_strips.append({'img': l3, 'x': 0, 'speed': 1.0})
        
    def update(self, scroll_speed):
        for strip in self.bg_strips:
            strip['x'] -= scroll_speed * strip['speed']
            if strip['x'] <= -SCREEN_WIDTH:
                strip['x'] += SCREEN_WIDTH

    def draw(self, surface):
        for strip in self.bg_strips:
            surface.blit(strip['img'], (strip['x'], 0))
            surface.blit(strip['img'], (strip['x'] + SCREEN_WIDTH, 0))
