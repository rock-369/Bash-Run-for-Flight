
from gtts import gTTS
import os

try:
    text = "Go back... go back..."
    tts = gTTS(text=text, lang='en', tld='co.uk', slow=True) 
    tts.save("assets/go_back.mp3")
    print("Audio generated successfully.")
except Exception as e:
    print(f"Error generating audio: {e}")
