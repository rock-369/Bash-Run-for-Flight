
import pygame

# Screen
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
TITLE = "Wingless Parrot Runner"

# Colors (R, G, B)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
GROUND_COLOR = (34, 139, 34) # Jungle Green
SKY_COLOR = (135, 206, 235)

# Physics & Game Settings
GRAVITY = 0.8
JUMP_FORCE = -18
SCROLL_SPEED = 5
SPEED_INCREASE_RATE = 0.001
MAX_SPEED = 12

# Player
PLAYER_WIDTH = 60 # Adjusted for sprites
PLAYER_HEIGHT = 60
PLAYER_CRAWL_HEIGHT = 40
PLAYER_X_POS = 100
PLAYER_COLOR = GREEN

# Projectiles
BULLET_SPEED = 12
BULLET_WIDTH = 20
BULLET_HEIGHT = 10
BULLET_COLOR = Cyan = (0, 255, 255)

# Enemies & Obstacles
FOX_WIDTH = 80
FOX_HEIGHT = 60
FOX_COLOR = (255, 100, 0)
FOX_SPEED = 7 

OBSTACLE_WIDTH = 50
OBSTACLE_HEIGHT = 50
OBSTACLE_COLOR = (100, 100, 100)
SPIKE_COLOR = (150, 0, 0)

# Ground
GROUND_HEIGHT = 500

# Paths
ASSET_DIR = "assets"
